function load(url){
	$("#page-wrapper").load(url);// 将url请求后响应的代码 放在#page-wrapper层中
}

$.ajaxSetup ({ 
    cache: false //关闭AJAX相应的缓存 
});
function cancelUser(){
	if(confirm("注销该账户后将不能继续使用该账户，是否确认注销？")){
		$.get("../cancelUser",function(resp){
			location.href="/bicycle-manager/index.html";
		});
	}
}

