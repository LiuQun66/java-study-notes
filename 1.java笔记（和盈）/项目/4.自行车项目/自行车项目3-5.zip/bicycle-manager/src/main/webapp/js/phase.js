//@ sourceURL=js/phase.js
// 上面的代码 后面路径写js文件的路径 保证浏览器在调试时 可以加载到该js页面
var vm = new Vue({
		el: "#phase",
		data: {
			pageInfo:{},
			list: [],
			isUpdate: false, // 标记是否是修改操作
			updateType:0,//0表示是新增操作
			msPhase: {}, // 保存新增和修改的数据对象
			queryCondition: {}, // 保存查询条件
			type: 1, //1不显示 2成功 3服务器异常,5表示有关联的权限不能删除
			valid: [true,true,true],//记录表单数据校验结果 默认都是通过的
			flag: true, //标记是否可以提交数据 默认可以
			notDupUrl:true, //标记url是否重复
			pNum:1
		},
		
		methods:{
			goPage: function(pageNum){
				this.pNum=pageNum;
				// 查询条件中携带要查询的页码
				this.queryCondition.pageNum = pageNum;
				var params = {
						params:this.queryCondition
				}
				
				this.$http.get("msphase/select",params).then(
						(resp) => {
							this.pageInfo = resp.body;
							this.list = resp.body.list;
						},
						(resp) => {
							
						}
				);
			},
			del:function(item){
				this.msPhase=item;
				//提示是否删除？
				if(confirm("是否删除？")){
					this.$http.get("../main/msphase/del",{params:this.msPhase})
					.then(function(res){
						let rb = res.bodyText;
						if(rb == "success"){
							this.type = 2;
						}else if(rb=="delFalse"){
							this.type=5;
						}else{
							this.type=3;
						}
					});
				}
				this.goPage(this.pNum);
				setTimeout('vm.type = 1',3000);
			},
			//点击修改操作：
			showDiv:function(item){
				this.updateType=item.phaseId;
				this.isUpdate=true;
				this.valid=[true,true,true];
				this.flag=true;
				//回显
				this.msPhase=item;
			},
			// 点击新增权限按钮
			addDiv: function(){
				this.updateType=0;
				this.isUpdate = false;
				this.msPhase = {};//清空表单数据
				this.valid = [true,true,true];
				this.flag = true;
				
			},
			//采用ajax验证数据库中是否有重复的url
			checkDupUrl:function(url){
					this.$http.get("../main/msphase/duplicationUrl",{params:{"url":url,"updateType":this.updateType}})
					.then(function(res){
						if(res.bodyText == "dupUrl"){
							this.notDupUrl=false;
							//this.type=4;
						}else if(res.bodyText == "success"){
							this.notDupUrl=true;
						}
					});
			},
			// 点击保存按钮操作
			save: function(){
				// 数据校验
				var urlOk = /^\/[a-zA-Z]{1,199}$/.test(this.msPhase.url);
				var descOk = /^[\u4e00-\u9fa5]{2,50}$/.test(this.msPhase.description);
				
				if(urlOk && descOk && this.notDupUrl){
					this.flag = true;
				}else{
					this.flag = false;
				}
				this.valid = [urlOk,descOk,this.notDupUrl];
				if(this.flag){// 可以提交
					if(this.isUpdate){
						url = "../main/msphase/update";
					}else{
						url = "../main/msphase/insert";
					}
				
					this.$http.post(url,this.msPhase,{emulateJSON: true}).then(
							(resp) => {
								var r = resp.bodyText;
								//关闭窗口
								$("#optDiv").modal('hide');
								if(r == "success"){
									//刷新当前 页
									if(this.isUpdate){
										this.goPage(this.pageInfo.pageNum);
									}
									this.type = 2;
								}
//										else if(r == "dupUrl"){
//									this.type = 4;
//									this.goPage(this.pNum);
//								}
								else{
									this.type = 3;
									this.goPage(this.pNum);
								}
								setTimeout('vm.type = 1',3000);
								this.msPhase = {};
							}
					);
					
				}
			},
			//点击取消按钮,则回到当前页
			cancel:function(){
				this.goPage(this.pNum);
			}
		}
	});
	
	vm.goPage(1); // 显示第1页数据