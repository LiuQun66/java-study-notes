//@ sourceURL=js/bicycle_order.js
// 上面的代码 后面路径写js文件的路径 保证浏览器在调试时 可以加载到该js页面
var uniqueId=1;//全局变量
var vm = new Vue({
		el: "#bicycle_order",
		data: {
			pageInfo:{},
			list: [],
			isUpdate: false, // 标记是否是修改操作
			updateType:0,//0表示是新增操作
			queryCondition: {}, // 保存查询条件
			type: 1, //1不显示 2成功 3服务器异常， 5表示不能删除该用户
			valid: [true,true,true,true],//记录表单数据校验结果 默认都是通过的
			flag: true,//标记是否可以提交数据 默认可以
			pNum:1,
			venderList:[],//存放供应商的名称
			bicycleKindList:[],//存放自行车的种类
			userName:"",//用户名
			operatorTime:"",//操作时间
			buyNum:0,//购买数量
			buyPrice:0,//总价格
			trList:[],//点击新增明细时表格新增行
			bicycle_order: {}, // 保存新增和修改的车辆购入主信息
			bicycle_order_detail:{},//保存新增和修改的车辆购入明细信息
			order_detail_List:[],//保存所有明细的集合
			detail_List:[]//修改时从根据对应的orderId查询出的对应明细信息。
		},
		
		methods:{
			goPage: function(pageNum){
				// 查询条件中携带要查询的页码
				this.pNum=pageNum;
				this.queryCondition.pageNum = pageNum;
				var params = {
						params:this.queryCondition
				}
				this.$http.get("bicycle_order/select",params).then(
						(resp) => {
							this.pageInfo = resp.body;
							this.list = resp.body.list;
						}
				);
			},
			del:function(item){
				//提示是否删除？
				if(confirm("是否删除？")){
					this.$http.get("../main/bicycle_order/del",{params:{"userId":item.userId}})
					.then(function(res){
						let rs=res.bodyText;
						if(rs == "delFalse"){
							this.type=5;
						}else if( rs == "success"){
							this.type = 2;
						}else{
							this.type = 3;
						}
					});
				}
				//更新列表
				this.goPage(this.pageInfo.pageNum);
				setTimeout('vm.type = 1',3000);
			},
			//点击查看按钮查看车辆购入的主信息和明细信息：
			showOrder:function(item){
				this.bicycle_order=item;
				$("#detailDiv").get(0).style.display="";
				this.getDetailsByOrderId(item);
			},
			//点击修改按钮操作
			showDiv:function(item){
				this.updateType=item.userId;
				this.isUpdate=true;
				valid: [true,true,true,true];
				this.flag=true;
				this.getVender();
				this.getCategory();
				this.bicycle_order=item;
				//根据车辆购入主信息id查询对应的明细单：
				this.getDetailsByOrderId(item);
			},
			// 点击新增车辆按钮
			addDiv: function(){
				this.updateType=0;
				this.isUpdate = false;
				this.bicycle_order = {};//清空车俩购入主信息单的数据
				this.bicycle_order_detail={};//清空车俩购入主信息单的数据
				this.bicycleKindList={};//清空自行车种类的数据
				this.trList=[];//清空增加明细时的行
				valid: [true,true,true,true];
				this.flag = true;
				this.operatorTime=this.createTime();
				this.buyNum=0;
				this.buyPrice=0;
				this.getVender();
				//获取用户名：
				this.$http.get("../main/syuser/getUsername").then(
						(resp) => {
							if(resp !="error"){
								this.userName=resp.bodyText;
								this.$set(this.bicycle_order,"userName",this.userName);
								this.$set(this.bicycle_order,"personInCharge",this.userName);
							}
						}
				);
				this.$set(this.bicycle_order,"operatorTime",this.operatorTime);
				this.$set(this.bicycle_order,"buyNum",this.buyNum);
				this.$set(this.bicycle_order,"buyPrice",this.buyPrice);
				this.getCategory();
			},
			//根据车辆购入主信息的id查询对应的明细信息：
			getDetailsByOrderId:function(item){
				this.$http.get("../main/bicycle_order_detail/selectByOrderId",{params:{"orderId":item.orderId}}).then(
						(resp) => {
							 this.detail_List = resp.body;
						}
				);
			},
			getVender:function(){
				//获取供应商信息：
				this.$http.get("../main/vender/selectVenders").then(
						(resp) => {
							this.venderList = resp.body;
						}
				);
			},
			getCategory:function(){
				//获取自行车种类：
				this.$http.get("../main/bicycle_catagory/selectBicycleCatagorys").then(
						(resp) => {
							this.bicycleKindList = resp.body;
						}
				);
			},
			//创建操作时间：
			createTime:function(){
				let date=new Date();
				let y=date.getFullYear();
				let m=date.getMonth()+1;
				m=this.checkTime(m);
				
				let d=date.getDate();
				d=this.checkTime(d);
				
				let h=date.getHours();
				h=this.checkTime(h);
				
				let mm=date.getMinutes();
				mm=this.checkTime(mm);
				
				let s=date.getSeconds();
				s=this.checkTime(s);
				let time=y+"-"+m+"-"+d+" "+h+":"+mm+":"+s;
				return time;
			},
			checkTime:function(t){
				if(t<10){
					t="0"+t;
				}
				return t;
			},
			//点击增加明细按钮增加明细：
			addDetailItem:function(){
				//trList原本是一个空数组：每次都存放uniqueId，这个是唯一的
				this.trList.push(uniqueId);
				uniqueId++;
				
			},
			//点击删除明细按钮进行删除
			delDetailItem:function(i){
				this.trList.splice(i,1);
			},
			//合计总价和总数量：
			checkPrice:function(){
				let totalPrice=0;
				let num=0;
				var priceList = document.getElementsByClassName("price_c");
				for(let i=0;i<priceList.length;i++){
					var p=priceList[i].value;
					totalPrice+=parseFloat(p);
					num+=1;
				}
				this.$set(this.bicycle_order,"buyNum",num);
				this.$set(this.bicycle_order,"buyPrice",totalPrice);
			},
			//新增明细：
			addDetail:function(){
				var detailRows = document.getElementsByClassName("detail_row");
				for(let j=0;j<detailRows.length;j++){
					let type = detailRows[j].children[1].children[0];
					let index = type.selectedIndex;;
					let selectType = type.options[index].value;
					let batchNo = detailRows[j].children[2].children[0].value;
					let price = detailRows[j].children[3].children[0].value;
					let remark = detailRows[j].children[4].children[0].value;
					this.bicycle_order_detail={"catagoryId":selectType,"batchNo":batchNo,"price":price,"remark":remark};
					this.order_detail_List.push(this.bicycle_order_detail);
				}
				return this.order_detail_List;
			},
			close:function(){
				//关闭窗口
				$("#detailDiv").modal('hide');
			},
			// 点击保存按钮操作
			save: function(){
				this.checkPrice();//刷新一个总金额和明细单数量
				// 数据校验
				var venderIdOk=false;//默认没有选择供应商
				var orderCodeOk = /^GC\d+$/.test(this.bicycle_order.orderCode);
				var invoiceNoOk = /[0-9][a-zA-Z0-9]{1,30}/.test(this.bicycle_order.invoiceNo);
				var buyDateOk= /^(([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))-02-29)$/.test(this.bicycle_order.buyDate);
				var venderId=this.bicycle_order.venderId;
				if(typeof(venderId)!="undefined"){
					venderIdOk=true;
				}
				
				if(orderCodeOk && invoiceNoOk && buyDateOk && venderIdOk){
					this.flag = true;
				}else{
					this.flag = false;
				}
				this.valid = [orderCodeOk,invoiceNoOk,buyDateOk,venderIdOk];
				if(this.flag){// 可以提交
					if(this.isUpdate){
						url = "../main/bicycle_order/update";
					}else{
						url = "../main/bicycle_order/insert";
						this.addDetail();
					}
					this.$http.post(url,{"bicycleOrder":JSON.stringify(this.bicycle_order),"orderDetailList":JSON.stringify(this.order_detail_List)},{emulateJSON: true}).then(
							(resp) => {
								var r = resp.bodyText;
								//关闭窗口
								$("#optDiv").modal('hide');
								if(r == "success"){
									//刷新当前 页
									if(this.isUpdate){
										this.goPage(this.pageInfo.pageNum);
									}
									this.type = 2;
								}else{
									this.type = 3;
									this.goPage(this.pageInfo.pageNum);
								}
								setTimeout('vm.type = 1',3000);
								this.bicycle_order = {};
								this.bicycle_order_detail={};
								this.order_detail_List=[];
							}
					);
				}
			},
			//点击取消按钮,则回到当前页
			cancel:function(){
				this.goPage(this.pNum);
			}
		}
	});
	vm.goPage(1); // 显示第1页数据
