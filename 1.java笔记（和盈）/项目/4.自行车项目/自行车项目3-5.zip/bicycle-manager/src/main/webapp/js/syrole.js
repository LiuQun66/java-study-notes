//@ sourceURL=js/syrole.js
// 上面的代码 后面路径写js文件的路径 保证浏览器在调试时 可以加载到该js页面
var vm = new Vue({
		el: "#syrole",
		data: {
			pageInfo:{},
			list: [],
			isUpdate: false, // 标记是否是修改操作
			updateType:0,//0表示是新增操作
			syRole: {}, // 保存新增和修改的数据对象
			queryCondition: {}, // 保存查询条件
			type: 1, //1不显示 2成功 3服务器异常,5表示已有用户使用了该角色，因此删除角色失败
			valid: [true,true,true],//记录表单数据校验结果 默认都是通过的
			flag: true,//标记是否可以提交数据 默认可以
			authorityList:[],//存放查询的所有权限信息
			checkedAuthList:[],//存放选中的角色权限复选框的内容
			pNum:1,
			temp:[],//临时存放数据
			notDupName:true//用来校验角色名称是否重复
		},
		
		methods:{
			goPage: function(pageNum){
				// 查询条件中携带要查询的页码
				this.pNum=pageNum;
				this.queryCondition.pageNum = pageNum;
				var params = {
						params:this.queryCondition
				}
				this.$http.get("syRole/select",params).then(
						(resp) => {
							this.pageInfo = resp.body;
							this.list = resp.body.list;
						}
				);
			},
			del:function(item){
				//提示是否删除？
				if(confirm("是否删除？")){
					this.$http.get("../main/syRole/del",{params:{"roleId":item.roleId}})
					.then(function(res){
						let rs=res.bodyText;
						if(rs == "delFalse"){
							this.type=5;
						}else if( rs == "success"){
							this.type = 2;
						}else{
							this.type = 3;
						}
					});
				}
				this.goPage(this.pageInfo.pageNum);
				setTimeout('vm.type = 1',3000);
				//更新列表
			},
			//点击修改按钮操作
			showDiv:function(item){
				this.updateType=item.roleId;
				this.isUpdate=true;
				this.valid=[true,true,true];
				this.flag=true;
				this.$http.get("../main/msphase/selectMsPhases").then(
						(resp) => {
							this.authorityList = resp.body;
						}
				);
				if(item.authList.length==0){
					this.syRole=item;
					this.$set(this.syRole,"authList",this.temp);
				}else{
					//回显
					this.syRole=item;
				}
			},
			// 点击新增权限按钮
			addDiv: function(){
				this.updateType=0;
				this.authorityList=[];//清空权限表
				this.isUpdate = false;
				this.syRole = {};//清空表单数据
				this.checkedAuthList=[];//将选中的角色权限清空
				this.valid = [true,true,true];
				this.flag = true;
				this.$http.get("../main/msphase/selectMsPhases").then(
						(resp) => {
							this.authorityList = resp.body;
						}
				);
			},
			checkDupRoleName:function(roleName){
					this.$http.get("../main/syRole/dupRoleName",{params:{"roleName":roleName,"updateType":this.updateType}})
					.then(function(res){
						if(res.bodyText == "dupRoleName"){
							this.notDupName=false;
							this.type=4;
						}else if(res.bodyText == "success"){
							this.notDupName=true;
						}
					});
			},
			// 点击保存按钮操作
			save: function(){
				// 数据校验
				var roleOk = /^[\u4e00-\u9fa5]{2,50}$/.test(this.syRole.roleName);
				var descOk = /^[\u4e00-\u9fa5]{2,50}$/.test(this.syRole.roleDescribe);
				
				if(roleOk && descOk && this.notDupName){
					this.flag = true;
				}else{
					this.flag = false;
				}
				this.valid = [roleOk,descOk,this.notDupName];
				if(this.flag){// 可以提交
					if(this.isUpdate){
						url = "../main/syRole/update";
						let tempList=this.syRole.authList;
						this.$set(this.syRole,"authList",JSON.stringify(tempList));
					}else{
						url = "../main/syRole/insert";
						this.$set(this.syRole,"authList",JSON.stringify(this.checkedAuthList));
					}
					
					this.$http.post(url,this.syRole,{emulateJSON: true}).then(
							(resp) => {
								var r = resp.bodyText;
								//关闭窗口
								$("#optDiv").modal('hide');
								if(r == "success"){
									//刷新当前 页
									if(this.isUpdate){
										this.goPage(this.pageInfo.pageNum);
									}
									this.type = 2;
								}else{
									this.type = 3;
									this.goPage(this.pageInfo.pageNum);
								}
								setTimeout('vm.type = 1',3000);
								this.syRole = {};
							}
					);
					
				}
			},
			//点击取消按钮,则回到当前页
			cancel:function(){
				this.goPage(this.pNum);
			}
		}
	});
	
	vm.goPage(1); // 显示第1页数据