//@ sourceURL=js/syuser.js
// 上面的代码 后面路径写js文件的路径 保证浏览器在调试时 可以加载到该js页面
var vm = new Vue({
		el: "#syuser",
		data: {
			pageInfo:{},
			list: [],
			isUpdate: false, // 标记是否是修改操作
			updateType:0,//0表示是新增操作
			syuser: {}, // 保存新增和修改的数据对象
			queryCondition: {}, // 保存查询条件
			type: 1, //1不显示 2成功 3服务器异常， 5表示不能删除该用户
			valid: [true,true,true,true,true,true,true],//记录表单数据校验结果 默认都是通过的
			flag: true,//标记是否可以提交数据 默认可以
			roleList:[],//存放查询的所有角色
			checkedRoleName:"",
			pNum:1,
			temp:[],//临时存放数据
			notDupName:true,
			checkRoleOk:true//新增用户时是否选择了角色
		},
		
		methods:{
			goPage: function(pageNum){
				// 查询条件中携带要查询的页码
				this.pNum=pageNum;
				this.queryCondition.pageNum = pageNum;
				var params = {
						params:this.queryCondition
				}
				this.$http.get("syuser/select",params).then(
						(resp) => {
							this.pageInfo = resp.body;
							this.list = resp.body.list;
						}
				);
			},
			del:function(item){
				//提示是否删除？
				if(confirm("是否删除？")){
					this.$http.get("../main/syuser/del",{params:{"userId":item.userId}})
					.then(function(res){
						let rs=res.bodyText;
						if(rs == "delFalse"){
							this.type=5;
						}else if( rs == "success"){
							this.type = 2;
						}else{
							this.type = 3;
						}
					});
				}
				//更新列表
				this.goPage(this.pageInfo.pageNum);
				setTimeout('vm.type = 1',3000);
			},
			//点击修改按钮操作
			showDiv:function(item){
				this.updateType=item.userId;
				this.isUpdate=true;
				valid: [true,true,true,true,true,true,true];
				this.flag=true;
				this.$http.get("../main/syRole/selectSyRoles").then(
						(resp) => {
							this.roleList = resp.body;
						}
				);
					this.syuser=item;
			},
			// 点击新增权限按钮
			addDiv: function(){
				this.updateType=0;
				this.roleList=[];//清空角色信息
				this.isUpdate = false;
				this.syuser = {};//清空表单数据
				this.checkedRoleName="";
				valid: [true,true,true,true,true,true,true];
				this.flag = true;
				this.$http.get("../main/syRole/selectSyRoles").then(
						(resp) => {
							this.roleList = resp.body;
						}
				);
			},
			checkDupLoginName:function(loginName){
					this.$http.get("../main/syRole/dupLoginName",{params:{"loginName":loginName,"updateType":this.updateType}})
					.then(function(res){
						if(res.bodyText == "dupLoginName"){
							this.notDupName=false;
							//this.type=4;
						}else if(res.bodyText == "success"){
							this.notDupName=true;
						}
					});
			},
			// 点击保存按钮操作
			save: function(){
				
				// 数据校验
				var lNameOk = false;
				var nameFlag = /^[a-zA-Z]{2,10}$/.test(this.syuser.loginName);
				if(nameFlag && this.syuser.loginName !=undefined){
					lNameOk=true;
				}
				var uNameOk = /^[\u4e00-\u9fa5]{2,10}$/.test(this.syuser.username);
				var pswOk= false;
				var pswFlag=/^[0-9A-Za-z]+$/.test(this.syuser.password);
				if(pswFlag && this.syuser.password !=undefined){
					pswOk=true;
				}
				var phoneOk=/^\d{11}$/.test(this.syuser.mobilePhone);
				var emailOk=/^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test(this.syuser.email);
				
				if(!this.isUpdate){
					if(this.checkedRoleName==""){
						this.checkRoleOk=false;
					}
				}
				this.checkedRoleName;
				
				if(lNameOk && uNameOk && pswOk && phoneOk && emailOk && this.notDupName && this.checkRoleOk){
					this.flag = true;
				}else{
					this.flag = false;
				}
					
				this.valid = [lNameOk,uNameOk,pswOk,phoneOk,emailOk,this.notDupName,this.checkRoleOk];
				if(this.flag){// 可以提交
					if(this.isUpdate){
						url = "../main/syuser/update";
					}else{
						url = "../main/syuser/insert";
						this.$set(this.syuser,"roleName",this.checkedRoleName);
						this.$set(this.syuser,"activeFlag",1);
						this.$set(this.syuser,"zxbj",1);
					}
					
					this.$http.post(url,this.syuser,{emulateJSON: true}).then(
							(resp) => {
								var r = resp.bodyText;
								//关闭窗口
								$("#optDiv").modal('hide');
								if(r == "success"){
									//刷新当前 页
									if(this.isUpdate){
										this.goPage(this.pageInfo.pageNum);
									}
									this.type = 2;
								}else{
									this.type = 3;
									this.goPage(this.pageInfo.pageNum);
								}
								setTimeout('vm.type = 1',3000);
								this.syuser = {};
								this.checkedRoleName="";
							}
					);
					
				}
			},
			//点击取消按钮,则回到当前页
			cancel:function(){
				this.goPage(this.pNum);
			}
		}
	});
	
	vm.goPage(1); // 显示第1页数据