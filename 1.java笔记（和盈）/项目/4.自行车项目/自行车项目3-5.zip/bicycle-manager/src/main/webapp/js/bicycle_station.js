//@ sourceURL=js/bicycle_station.js
// 上面的代码 后面路径写js文件的路径 保证浏览器在调试时 可以加载到该js页面
var uniqueId=1;//全局变量
var vm = new Vue({
		el: "#bicycle_station",
		data: {
			pageInfo:{},
			list: [],
			queryCondition: {}, // 保存查询条件
			selectBicycle:[],//存放选中的车辆的id
			type: 1, //1不显示 2成功 3服务器异常， 4进入选择车点时的提醒内容,5选择的车辆数与车桩数不匹配提示
			flag: true,//标记是否可以提交数据 默认可以
			pNum:1,
			bicycle_station:[],//存放查询的车点信息
			pageInfo2:{},//车点信息查询的分页信息
			bicycle_pile:[],//存放查询的车桩信息
			selectPiles:[],//存放选择的车桩
			stationName:"",//查看车桩所在的车点名称
		},
		
		methods:{
			goPage: function(pageNum){
				this.pNum=pageNum;
				// 查询条件中携带要查询的页码
				this.queryCondition.pageNum = pageNum;
				var params = {
						params:this.queryCondition
				}
				this.$http.get("../main/bicycle_info/select",params).then(
						(resp) => {
							this.pageInfo = resp.body;
							this.list = resp.body.list;
						}
					);
			},
			// 点击选择车点按钮
			chooseStation: function(){
					this.type=4;
					this.flag = true;
					this.stationGoPage(1);
			},
			//分页查询车点信息:
			stationGoPage:function(pageNum){
				this.$http.get("../main/bicycle_station/select",{params:{"pageNum":pageNum}}).then(
						(resp) => {
							this.pageInfo2 = resp.body;
							this.bicycle_station = resp.body.list;
						}
				);
			},
			//选择车点中对应的车桩:
			choosePile:function(station){
				this.stationName=station.stationName;
				let stationId=station.stationId;
				//查询出车点id中对应的车桩信息:
				this.$http.get("../main/bicycle_pile/select",{params:{"stationId":stationId}}).then(
						(resp) => {
							this.bicycle_pile=resp.body;
						}
				);
			},
			//关闭车桩选择的窗口
			close:function(){
				$("#pileDiv").modal('hide');
			},
			// 点击确定入桩按钮
			save: function(){
				//校验选择的车辆数和车桩数是否一致：
				let length1=this.selectPiles.length;
				let length2=this.selectBicycle.length;
				if(length1==length2 && length1>0){
					this.flag=true;
				}else{
					this.flag=false;
					this.type=5;
				}
				let bicyclesStr=JSON.stringify(this.selectBicycle);
				let pilesStr=JSON.stringify(this.selectPiles);
				if(this.flag){// 可以提交
					this.$http.post("../main/bicycle_info/update",{"selectBicycle":bicyclesStr,"selectPiles":pilesStr},{emulateJSON: true}).then(
							(resp) => {
								var r = resp.bodyText;
								//关闭窗口
								$("#stationDiv").modal('hide');
								if(r == "success"){
									this.goPage(this.pageInfo.pageNum);
									this.type = 2;
								}else{
									this.type = 3;
									this.goPage(this.pageInfo.pageNum);
								}
								setTimeout('vm.type = 1',3000);
								this.bicycle_station = {};
								this.selectBicycle=[];//选中的车辆清空
								this.selectPiles=[];//清空选择的车桩
							}
					);
				}
			},
			//选择车点中的返回按钮：
			cancel:function(){
				//关闭车点选择的窗口
				$("#stationDiv").modal('hide');
				this.selectPiles=[];//清空选择的车桩
			}
		}
	});
	vm.goPage(1); // 显示第1页数据
