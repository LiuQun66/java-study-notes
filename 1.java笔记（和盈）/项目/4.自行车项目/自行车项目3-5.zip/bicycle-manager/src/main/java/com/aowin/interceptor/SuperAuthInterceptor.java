package com.aowin.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;

import com.aowin.model.Syuser;

public class SuperAuthInterceptor implements HandlerInterceptor{
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		Syuser user = (Syuser) request.getSession().getAttribute("syuser");
		if(user == null) {
			response.sendRedirect(request.getContextPath()+"/index.html");
			return false;
		}else if("超级管理员".equals(user.getRoleName())) {
			return true;
		}else {
			return false;
		}
	}
}
