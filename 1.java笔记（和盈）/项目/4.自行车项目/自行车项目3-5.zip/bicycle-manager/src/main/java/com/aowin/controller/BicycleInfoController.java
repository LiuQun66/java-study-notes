package com.aowin.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.aowin.model.BicycleInfo;
import com.aowin.model.Syuser;
import com.aowin.service.BicycleInfoService;
import com.github.pagehelper.PageInfo;

@RestController
@RequestMapping("/main/bicycle_info")
public class BicycleInfoController {
	private Logger logger = Logger.getLogger(BicycleInfoController.class);
	
	@Autowired
	private BicycleInfoService infoService;
	/**
	 * 分页：
	 * @param pageNum
	 * @return
	 */
	@RequestMapping("/select")
	public PageInfo<BicycleInfo> select(@RequestParam(defaultValue = "1") int pageNum){
		return infoService.select(pageNum);
	}
	
	@RequestMapping("/update")
	public String updateBicycleInfoAndPile(String selectBicycle,String selectPiles,HttpSession session) {
		try {
			Syuser user = (Syuser) session.getAttribute("syuser");
			Integer userId=user.getUserId();
			List<Integer> bicycleIdList = JSON.parseArray(selectBicycle, Integer.class);
			List<Integer> pileIdList = JSON.parseArray(selectPiles,Integer.class);
			infoService.updateBicycleInfoAndPile(bicycleIdList, pileIdList, userId);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
	}
	
}
