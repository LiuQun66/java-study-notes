package com.aowin.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aowin.model.Syuser;
import com.aowin.service.SyuserService;
import com.github.pagehelper.PageInfo;

@Controller
public class SyuserController {
	private Logger logger = Logger.getLogger(SyuserController.class);
	@Autowired
	private SyuserService syuserServiceImpl;
	
	/**
	 * 用户登录：
	 * @param syuser
	 * @param br
	 * @param session
	 * @return
	 */
	@RequestMapping("/login")
	@ResponseBody
	public Syuser login(@Validated Syuser syuser,BindingResult br, HttpSession session) {
		//如果验证不合法 直接返回
		if(br.hasErrors()) {
			return null;
		}
		Syuser user = syuserServiceImpl.login(syuser);
		if(user != null && "1".equals(user.getZxbj())) {
			session.setAttribute("syuser", user);
			return user;
		}
		return null;
	}
	
	/**
	 * 用户退出：
	 * @param session
	 * @return
	 */
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		//用户退出
		session.removeAttribute("syuser");//销毁单个session的属性
		return "redirect:/index.html";
	}
	/**
	 * 用户注销：
	 * @return
	 */
	@RequestMapping("/cancelUser")
	public String cancelUser(HttpSession session) {
		Syuser user=(Syuser) session.getAttribute("syuser");
		user.setZxbj("2");
		syuserServiceImpl.updateZxbj(user);
		session.invalidate();
		return "redirect:/index.html";
	}
	/**
	 * 分页查询：
	 * @param pageNum
	 * @param syuser
	 * @return
	 */
	@RequestMapping("/main/syuser/select")
	@ResponseBody
	public PageInfo<Syuser> select(@RequestParam(defaultValue = "1") int pageNum, Syuser syuser) {
		return syuserServiceImpl.select(pageNum, syuser);
	}
	/**
	 * 新增用户
	 * @param syuser
	 * @param br
	 * @return
	 */
	@RequestMapping("/main/syuser/insert")
	@ResponseBody
	public String insert(Syuser syuser,BindingResult br) {
		if(br.hasErrors()) {
			return "fail";
		}
		try {
			syuserServiceImpl.insert(syuser);
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
		return "success";
	}
	/**
	 * 查询是否有重复的用户登录名称：
	 * @param loginName
	 * @return
	 */
	@RequestMapping("/main/syRole/dupLoginName")
	@ResponseBody
	public String selectDupLoginName(String loginName,Integer updateType) {
		try {
			List<Syuser> userList = syuserServiceImpl.selectByLoginName(loginName);
			if(userList!=null && userList.size()>0) {
				if(userList.size()==1&&userList.get(0).getUserId()==updateType) {
					return "success";
				}
				return "dupLoginName";
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
		return "success";
	}
	@RequestMapping("/main/syuser/update")
	@ResponseBody
	public String update(Syuser syuser) {
		try {
			syuserServiceImpl.update(syuser);
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
		return "success";
	}
	@RequestMapping("/main/syuser/del")
	@ResponseBody
	public String del(Integer userId) {
		// 删除角色
		try {
			boolean flag = syuserServiceImpl.deleteById(userId);
			if(!flag) {
				return "delFalse";
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
		return "success";
	}
	@RequestMapping("/main/syuser/getUsername")
	@ResponseBody
	public String getUsername(HttpSession session) {
		try {
			Syuser syuser = (Syuser) session.getAttribute("syuser");
			return syuser.getUsername();
		}catch(Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
	}

}
