package com.aowin.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.aowin.model.BicycleOrder;
import com.aowin.model.BicycleOrderDetail;
import com.aowin.model.Syuser;
import com.aowin.service.BicycleOrderService;
import com.github.pagehelper.PageInfo;
@RestController
@RequestMapping("/main/bicycle_order")
public class BicycleOrderController {
	private Logger logger = Logger.getLogger(BicycleOrderController.class);
	
	@Autowired
	private BicycleOrderService orderService;
	/**
	 * 分页：
	 * @param pageNum
	 * @param bicycleOrder
	 * @return
	 */
	@RequestMapping("/select")
	public PageInfo<BicycleOrder> select(@RequestParam(defaultValue = "1") int pageNum,BicycleOrder bicycleOrder){
		return orderService.select(pageNum, bicycleOrder);
	}
	
	@RequestMapping("/insert")
	public String insert(@RequestParam("bicycleOrder") String bicycleOrder,String orderDetailList,HttpSession session) {
		try {
			Syuser user=(Syuser) session.getAttribute("syuser");
			BicycleOrder order = JSON.parseObject(bicycleOrder, BicycleOrder.class);
			order.setUserId(user.getUserId());
			List<BicycleOrderDetail> detailList = JSON.parseArray(orderDetailList, BicycleOrderDetail.class);
			orderService.insertBicycleOrder(order, detailList);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
	}
}
