package com.aowin.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aowin.model.BicycleStation;
import com.aowin.service.BicycleStationService;
import com.github.pagehelper.PageInfo;

@RestController
@RequestMapping("/main/bicycle_station")
public class BicycleStationController {
	private Logger logger = Logger.getLogger(BicycleStationController.class);
	@Autowired
	private BicycleStationService stationService;
	/**
	 * 分页查询车点信息：
	 * @param pageNum
	 * @return
	 */
	@RequestMapping("/select")
	public PageInfo<BicycleStation> select(@RequestParam(defaultValue = "1") int pageNum){
		return stationService.select(pageNum);
	}
}
