package com.aowin.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aowin.model.SyRole;
import com.aowin.model.Syuser;
import com.aowin.service.SyRoleService;
import com.aowin.util.StringParseUtil;
import com.github.pagehelper.PageInfo;

@RestController
@RequestMapping("/main/syRole")
public class SyRoleController {
	private Logger logger = Logger.getLogger(SyRoleController.class);
	
	@Autowired
	private SyRoleService syRoleService;
	
	@RequestMapping("/select")
	public PageInfo<SyRole> select(@RequestParam(defaultValue = "1") int pageNum,SyRole syRole){
		return syRoleService.select(pageNum, syRole);
	}
	
	/**
	 * 数据校验 在需要被校验的对象上 添加@Validated 跟在这个参数后面添加一个BindingResult的对象
	 * 
	 * BindingResult 对象用来保存验证的结果的
	 * @param syRole
	 * @param br
	 * @return
	 */
	@RequestMapping("/insert")
	public String insert(SyRole syRole,BindingResult br) {
		if(br.hasErrors()) {
			return "fail";
		}
		List<String> newAuthList = StringParseUtil.parseStringList(syRole.getAuthList());
		try {
			syRole.setAuthList(newAuthList);
			syRoleService.insertSyRole(syRole);
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
		return "success";
	}
	/**
	 * 新增角色：
	 * @param syRole
	 * @param br
	 * @return
	 */
	@RequestMapping("/update")
	public String update(SyRole syRole,BindingResult br) {
		if(br.hasErrors()) {
			List<FieldError> fs = br.getFieldErrors();
			for (FieldError f : fs) {
				System.out.println(f.getDefaultMessage());
			}
			return "error";
		}
		List<String> newAuthList = StringParseUtil.parseStringList(syRole.getAuthList());
		syRole.setAuthList(newAuthList);
		//更新权限数据
		try {
			syRoleService.updateSyRole(syRole);
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
		return "success";
	}
	
	
	@RequestMapping("/del")
	public String del(Integer roleId) {
		//删除角色
		try {
			boolean flag = syRoleService.deleteById(roleId);
			if(!flag) {
				return "delFalse";
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
		return "success";
	}
	/**
	 * 查询所有的角色信息
	 * @param syRole
	 * @return
	 */
	@RequestMapping("/selectSyRoles")
	public List<SyRole> selectSyRoles(SyRole syRole) {
		return syRoleService.selectSyRoles(null);
	}
	/**
	 * 查询是否有重复的角色名称：
	 * @param roleName
	 * @return
	 */
	@RequestMapping("/dupRoleName")
	public String selectDupRoleName(String roleName,Integer updateType) {
		try {
			List<Integer> roleList = syRoleService.selectByRoleName(roleName);
			if(roleList!=null && roleList.size()>0) {
				if(roleList.size()==1&&roleList.get(0)==updateType) {
					return "success";
				}
				return "dupRoleName";
			}
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
		return "success";
	}
}
