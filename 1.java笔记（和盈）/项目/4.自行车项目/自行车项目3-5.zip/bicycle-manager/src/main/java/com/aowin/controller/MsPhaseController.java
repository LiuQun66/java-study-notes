package com.aowin.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aowin.model.MsPhase;
import com.aowin.service.MsPhaseService;
import com.github.pagehelper.PageInfo;

@RestController
@RequestMapping("/main/msphase")
public class MsPhaseController {

	private Logger logger = Logger.getLogger(MsPhaseController.class);

	@Autowired
	private MsPhaseService msPhaseService;

	@RequestMapping("/select")
	public PageInfo<MsPhase> select(@RequestParam(defaultValue = "1") int pageNum, MsPhase msPhase) {
		return msPhaseService.select(pageNum, msPhase);
	}

	/**
	 * 数据校验 在需要被校验的对象上 添加@Validated 跟在这个参数后面添加一个BindingResult的对象
	 * 
	 * BindingResult 对象用来保存验证的结果的
	 * 
	 * @param msPhase
	 * @param br
	 * @return
	 */
	@RequestMapping("/insert")
	public String insert(@Valid MsPhase msPhase, BindingResult br) {
		if (br.hasErrors()) {
			return "fail";
		}
		try {
			msPhaseService.insert(msPhase);
			return "success";
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
	}

	@RequestMapping("/update")
	public String update(@Valid MsPhase msPhase, BindingResult br) {
		if (br.hasErrors()) {
			List<FieldError> fs = br.getFieldErrors();
			for (FieldError f : fs) {
				System.out.println(f.getDefaultMessage());
			}
			return "error";
		}
		// 更新权限数据
		try {
			boolean flag = msPhaseService.update(msPhase);
			if(!flag) {
				return "dupUrl";
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
		return "success";
	}

	@RequestMapping("/del")
	public String del(MsPhase msPhase) {
		// 删除权限数据
		try {
			boolean flag = msPhaseService.delete(msPhase.getPhaseId());
			if(!flag) {
				return "delFalse";
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
		return "success";
	}

	/**
	 * 查询所有的权限：在角色修改中使用到了
	 * 
	 * @return
	 */
	@RequestMapping("/selectMsPhases")
	public List<MsPhase> selectMsPhases() {
		return msPhaseService.selectMsPhases(null);
	}

	/**
	 * 校验数据库中是否有重复的url
	 * 
	 * @param url
	 * @return
	 */
	@RequestMapping("/duplicationUrl")
	public String duplicationUrl(String url,Integer updateType) {
		try {
			MsPhase phase = msPhaseService.selectMsPhaseByUrl(url);
			if (phase == null) {
				return "success";
			}else if(phase !=null && phase.getPhaseId()==updateType){
				return "success";
			}else {
				return "dupUrl";
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("服务端异常", e);
			return "error";
		}
	}

}
