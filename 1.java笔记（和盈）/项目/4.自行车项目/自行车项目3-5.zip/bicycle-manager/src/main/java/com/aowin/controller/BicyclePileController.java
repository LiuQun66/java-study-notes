package com.aowin.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aowin.model.BicyclePile;
import com.aowin.service.BicyclePileService;

@RestController
@RequestMapping("/main/bicycle_pile")
public class BicyclePileController {
	private Logger logger = Logger.getLogger(BicyclePileController.class);
	@Autowired
	private BicyclePileService pileService;
	/**
	 * 根据车点id查询车桩信息：
	 * @param pageNum
	 * @return
	 */
	@RequestMapping("/select")
	private List<BicyclePile> selectPiles(Integer stationId){
		return pileService.selectPilesById(stationId);
	}
}
