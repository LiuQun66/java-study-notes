package com.aowin.dao;

import java.util.List;

import com.aowin.model.BicycleOrderDetail;

public interface BicycleOrderDetailMapper {
	/**
	 * 新增车辆购入明细：
	 * @param detail
	 * @return
	 */
	int insertDetail(BicycleOrderDetail detail);
	/**
	 * 根据车辆购入主单的id查询对应的明细单信息
	 * @param orderId
	 * @return
	 */
	List<BicycleOrderDetail> selectByOrderId(Integer orderId);
}
