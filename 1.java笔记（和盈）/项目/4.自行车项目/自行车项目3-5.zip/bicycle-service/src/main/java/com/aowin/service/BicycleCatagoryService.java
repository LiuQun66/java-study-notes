package com.aowin.service;

import java.util.List;

import com.aowin.model.BicycleCatagory;

public interface BicycleCatagoryService {
	/**
	 * 查询自行车的种类：
	 * @return
	 */
	List<BicycleCatagory> selectCatagorys();
}
