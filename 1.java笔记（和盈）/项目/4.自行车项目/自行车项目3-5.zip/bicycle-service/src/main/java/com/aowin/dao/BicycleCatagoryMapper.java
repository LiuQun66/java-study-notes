package com.aowin.dao;

import java.util.List;

import com.aowin.model.BicycleCatagory;

public interface BicycleCatagoryMapper {
	/**
	 * 查询自行车的种类：
	 * @return
	 */
	List<BicycleCatagory> selectCatagorys();
}
