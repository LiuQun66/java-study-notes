package com.aowin.service;

import java.util.List;

import com.aowin.model.MsPhase;
import com.github.pagehelper.PageInfo;

public interface MsPhaseService {
	 PageInfo<MsPhase> select(int pageNum,MsPhase msPhase);
	/**
	 * 新增权限
	 * @param msPhone
	 * @return
	 */
	 int insert(MsPhase msPhase);
	/**
	 * 修改权限
	 * @param msPhase
	 * @return
	 */
	 boolean update(MsPhase msPhase);

	/**
	 * 删除权限
	 * @param phaseId
	 * @return
	 */
	 boolean delete(int phaseId) ;
	/**
	 * 根据id查询权限
	 * @param phaseId
	 * @return
	 */
	 MsPhase selectById(int phaseId);
	 /**
	  * 根据url查询权限的url信息
	  * @param url
	  * @return
	  */
	 MsPhase selectMsPhaseByUrl(String url);
	/**
	 * 查询所有的权限信息
	 * @return
	 */
	 List<MsPhase> selectMsPhases(MsPhase msPhase);
}
