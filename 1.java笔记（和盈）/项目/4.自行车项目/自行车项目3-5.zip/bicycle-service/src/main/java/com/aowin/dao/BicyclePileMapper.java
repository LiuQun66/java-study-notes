package com.aowin.dao;

import java.util.List;
import java.util.Map;

import com.aowin.model.BicyclePile;

public interface BicyclePileMapper {
	/**
	 * 根据车点id查询对应的车桩信息：
	 * @param stationId
	 * @return
	 */
	List<BicyclePile> selectPilesById(Integer stationId);
	/**
	 * 根据车桩id修改车桩信息
	 * @param map
	 * @return
	 */
	int updateBicyclePileById(Map<String,Object> map);
}
