package com.aowin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aowin.dao.VenderMapper;
import com.aowin.model.Vender;
import com.aowin.service.VenderService;
@Service
public class VenderServiceImpl implements VenderService{
	@Autowired
	private VenderMapper venderMapper;
	/**
	 * 查询供应商的信息：
	 */
	@Override
	public List<Vender> selectVenders() {
		return venderMapper.selectVenders();
	}
	
}
