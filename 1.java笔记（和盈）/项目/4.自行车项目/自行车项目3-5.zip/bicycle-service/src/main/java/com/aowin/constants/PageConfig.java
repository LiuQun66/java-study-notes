package com.aowin.constants;

public interface PageConfig {
	
	int PAGE_SIZE = 4;

}
