package com.aowin.dao;

import java.util.List;

import com.aowin.model.BicycleStation;

public interface BicycleStationMapper {
	/**
	 * 查询车点信息：
	 * @return
	 */
	List<BicycleStation> selectBicycleStations();
}
