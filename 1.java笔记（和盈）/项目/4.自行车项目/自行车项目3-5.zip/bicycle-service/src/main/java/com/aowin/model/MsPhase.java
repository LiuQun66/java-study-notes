package com.aowin.model;

import java.io.Serializable;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.URL;


public class MsPhase implements Serializable{
	private static final long serialVersionUID = 1L;

	/* @NotNull (groups = Update.class) */
	private Integer phaseId;
	
	//url 以/开头的只能有字母数字组成 最大长度200
	@Pattern(regexp = "/[a-zA-Z\\d]{1,199}")
	@NotEmpty(message = "url错误")
	private String url;
	
	//描述 中文汉字 最多50个字符
	@Pattern(regexp = "[\u4e00-\u9fa5]{1,50}")
	@NotEmpty(message = "描述错误")
	private String description;
	
//	
//	@Max(value = 150)
//	@Min(value = 2)
	//@URL(message = "")
	
	public Integer getPhaseId() {
		return phaseId;
	}
	public void setPhaseId(Integer phaseId) {
		this.phaseId = phaseId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "MsPhase [phaseId=" + phaseId + ", url=" + url + ", description=" + description + "]";
	}
}
