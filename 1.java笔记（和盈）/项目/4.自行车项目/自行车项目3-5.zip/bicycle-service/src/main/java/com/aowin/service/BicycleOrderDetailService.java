package com.aowin.service;

import java.util.List;

import com.aowin.model.BicycleOrderDetail;

public interface BicycleOrderDetailService {
	/**
	 * 根据车辆购入主单的id查询对应的明细单信息
	 * @param orderId
	 * @return
	 */
	List<BicycleOrderDetail> selectByOrderId(Integer orderId);
}
