package com.aowin.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {
	/**
	 * 获得指定格式的日期：
	 * @return
	 */
	public static String getDate() {
		Calendar c=Calendar.getInstance();
		Date time=c.getTime();
		SimpleDateFormat dateformat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return dateformat.format(time);
	}
}
