package com.aowin.service;

import java.util.List;

import com.aowin.model.BicycleOrder;
import com.aowin.model.BicycleOrderDetail;
import com.github.pagehelper.PageInfo;

public interface BicycleOrderService {
	/**
	 * 分页：
	 * @param pageNum
	 * @param syRole
	 * @return
	 */
	PageInfo<BicycleOrder> select(int pageNum,BicycleOrder bicycleOrder);
	/**
	 * 查询车辆购入主信息
	 * @param bicycleOrder
	 * @return
	 */
	//List<BicycleOrder> selectBicycleOrder(BicycleOrder bicycleOrder);
	
	/**
	 * 新增车辆购入主信息：
	 * @param bicycleOrder
	 */
	void insertBicycleOrder(BicycleOrder order,List<BicycleOrderDetail> detailList);
}
