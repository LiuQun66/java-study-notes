package com.aowin.dao;

import com.aowin.model.BicycleDeploy;

public interface BicycleDeployMapper {
	/**
	 * 新增车俩调配明细：
	 * @param deploy
	 * @return
	 */
	int insertBicycleDeploy(BicycleDeploy deploy);
}
