package com.aowin.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BicycleOrder implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer orderId;
	private String orderCode;
	private Integer venderId;
	private String venderName;
	private String buyDate;
	private Double buyNum;
	private Double buyPrice;
	private String personInCharge;
	private String invoiceNo;
	private Integer userId;
	private String userName;
	private String operatorTime;
	private String remark;
}
