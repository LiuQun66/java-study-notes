package com.aowin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aowin.dao.BicycleInfoMapper;
import com.aowin.dao.BicyclePileMapper;
import com.aowin.model.BicyclePile;
import com.aowin.service.BicyclePileService;
@Service
public class BicyclePileServiceImple implements BicyclePileService{
	@Autowired
	private BicyclePileMapper pileMapper;
	@Autowired
	private BicycleInfoMapper infoMapper;
	/**
	 * 根据车点id查询对应的车桩信息：
	 */
	@Override
	public List<BicyclePile> selectPilesById(Integer stationId) {
		List<BicyclePile> pileList=pileMapper.selectPilesById(stationId);
		for(BicyclePile pile:pileList) {
			if(pile.getBicycleId()!=null) {
				Integer bicycleCode = infoMapper.selectById(pile.getBicycleId());
				pile.setBicycleCode(bicycleCode);
			}
		}
		return pileList;
	}

}
