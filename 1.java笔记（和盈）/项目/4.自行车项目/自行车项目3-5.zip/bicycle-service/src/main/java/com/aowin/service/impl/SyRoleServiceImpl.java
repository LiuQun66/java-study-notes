package com.aowin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aowin.constants.PageConfig;
import com.aowin.dao.MsPhaseMapper;
import com.aowin.dao.SyPermissionMapper;
import com.aowin.dao.SyRoleMapper;
import com.aowin.dao.SyuserMapper;
import com.aowin.model.MsPhase;
import com.aowin.model.SyRole;
import com.aowin.model.Syuser;
import com.aowin.service.SyRoleService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
@Service
public class SyRoleServiceImpl implements SyRoleService{
	@Autowired
	private SyRoleMapper syRoleMapper;
	@Autowired
	private MsPhaseMapper msPhaseMapper;
	@Autowired
	private SyPermissionMapper permissionMapper;
	@Autowired
	private SyuserMapper syuserMapper;
	/**
	 * 分页
	 */
	@Override
	public PageInfo<SyRole> select(int pageNum, SyRole syRole) {
		PageHelper.startPage(pageNum, PageConfig.PAGE_SIZE);
		List<SyRole> roles = syRoleMapper.selectSyRoles(syRole);
		return new PageInfo<SyRole>(roles);
	}
	/**
	 * 查询角色信息
	 */
	@Override
	public List<SyRole> selectSyRoles(SyRole syRole) {
		return syRoleMapper.selectSyRoles(syRole);
	}
	/**
	 * 新增角色
	 */
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false, rollbackFor = Exception.class)
	@Override
	public void insertSyRole(SyRole syRole) {
		//新增角色操作：需要使用到事务
		//1.syrole表中新增角色
		syRoleMapper.insertSyRole(syRole);
		//2.sypermission表中添加角色的权限：
		Integer roleId=syRole.getRoleId();//获取新增角色的roleId:
		List<String> urlList = syRole.getAuthList();
		for(String url:urlList) {
			MsPhase msPhase = msPhaseMapper.selectMsPhaseByUrl(url);//根据url获取msphase表的phaseId:
			if(msPhase!=null) {
				Map<String,Integer> map=new HashMap<String, Integer>();
				map.put("roleId", roleId);
				map.put("phaseId", msPhase.getPhaseId());
				permissionMapper.insertSyPermission(map);//给角色添加权限
			}
		}
	}
	/**
	 * 修改角色
	 */
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false, rollbackFor = Exception.class)
	@Override
	public void updateSyRole(SyRole syRole) {
		//更新角色(syrole表)：
		 syRoleMapper.updateSyRole(syRole);
		 Integer roleId=syRole.getRoleId();
		 //更新角色权限表(sypermission表)：
		 	//根据roleId删除所对应的权限信息(sypermission表)：
		 permissionMapper.deleteByRoleId(roleId);
		 	//根据authList中的内容查询对应的phaseId(msPhase表)：
		 for(String s:syRole.getAuthList()) {
			 List<Integer> phaseIdList = msPhaseMapper.selectByDesc(s);
			 if(phaseIdList.size()>1) {
				 throw new RuntimeException("根据描述查询的phaseId不唯一");
			 }else if(phaseIdList.size()==1) {
				//根据roleId、phaseId新增角色的权限(sypermission表)：
				 Map<String,Integer> map=new HashMap<String, Integer>();
				 map.put("roleId", roleId);
				 map.put("phaseId",phaseIdList.get(0));
				 permissionMapper.insertSyPermission(map);
			 }
		 }
	}
	/**
	 * 根据Id查询角色
	 */
//	@Override
//	public SyRole selectById(int syRoleId) {
//		return syRoleMapper.selectById(syRoleId);
//	}
	/**
	 * 根据id删除角色
	 */
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false, rollbackFor = Exception.class)
	@Override
	public boolean deleteById(int syRoleId) {
		//要先查询用户中是否有该角色，若有则不能删除，若没有则可以删除：
		List<Syuser> userList = syuserMapper.selectByroleId(syRoleId);
		if(userList!=null && userList.size()>0) {
			return false;
		}else {
			//要先根据roleId删除角色的权限信息：
			permissionMapper.deleteByRoleId(syRoleId);
			//再根据roleId删除角色
			syRoleMapper.deleteById(syRoleId);
			return true;
		}
	}
	/**
	  * 根据id查询出角色对应的权限信息
	  * @param syRoleId
	  * @return
	  */
//	@Override
//	public SyRole selectPhaseDescribeById(int syRoleId) {
//		return syRoleMapper.selectPhaseDescribeById(syRoleId);
//	}
	/**
	  * 根据角色名称查询角色id
	  * @param roleName
	  * @return
	  */
	@Override
	public List<Integer> selectByRoleName(String roleName) {
		return syRoleMapper.selectByRoleName(roleName);
	}

	

}
