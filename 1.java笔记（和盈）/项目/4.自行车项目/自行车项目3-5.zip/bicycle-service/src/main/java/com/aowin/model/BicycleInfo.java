package com.aowin.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BicycleInfo implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer bicycleId;
	private Integer bicycleCode;
	private Integer status;
	private Integer pileId;
	private String destroyDate;
	private Integer userId;
	private String operatorTime;
	private Integer cardId;
	private String remark;
}
