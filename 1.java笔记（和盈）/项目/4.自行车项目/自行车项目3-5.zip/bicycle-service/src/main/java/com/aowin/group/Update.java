package com.aowin.group;

public interface Update {

}
