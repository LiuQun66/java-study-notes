package com.aowin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aowin.constants.PageConfig;
import com.aowin.dao.BicycleDealMapper;
import com.aowin.dao.BicycleInfoMapper;
import com.aowin.dao.BicycleOrderDetailMapper;
import com.aowin.dao.BicycleOrderMapper;
import com.aowin.model.BicycleDeal;
import com.aowin.model.BicycleInfo;
import com.aowin.model.BicycleOrder;
import com.aowin.model.BicycleOrderDetail;
import com.aowin.service.BicycleOrderService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
@Service
public class BicycleOrderServiceImpl implements BicycleOrderService{
	@Autowired
	private BicycleOrderMapper orderMapper;
	@Autowired
	private BicycleOrderDetailMapper detailMapper;
	@Autowired
	private BicycleInfoMapper infoMapper;
	@Autowired
	private BicycleDealMapper dealMapper;
	/**
	 * 分页：
	 */
	@Override
	public PageInfo<BicycleOrder> select(int pageNum, BicycleOrder bicycleOrder) {
		PageHelper.startPage(pageNum, PageConfig.PAGE_SIZE);
		List<BicycleOrder> orderList = orderMapper.selectBicycleOrder(bicycleOrder);
		return new PageInfo<BicycleOrder>(orderList);
	}
	/**
	 * 新增车辆购入主信息和明细信息
	 */
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false, rollbackFor = Exception.class)
	@Override
	public void insertBicycleOrder(BicycleOrder order,List<BicycleOrderDetail> detailList) {
		//新增车辆购入主信息：
		int row1 = orderMapper.insertBicycleOrder(order);
		if(row1>0) {
			Integer orderId=order.getOrderId();
			Integer userId=order.getUserId();
			String operatorTime=order.getOperatorTime();
			//新增车辆购入明细信息：
			for(BicycleOrderDetail detail:detailList) {
				Double price =detail.getPrice();
				detail.setOrderId(orderId);//每条明细都对应主信息的id
				detail.setCreateDate(operatorTime);
				//1.每一条明细都对应一个车辆状态信息：新增一条车辆状态信息
				BicycleInfo info=new BicycleInfo();
				Integer bicycleCode = infoMapper.selectMaxCode();//查询车辆状态信息中车辆编码的最大值
				info.setBicycleCode(bicycleCode+1);
				info.setStatus(1);//1表示车辆购入且未入桩
				info.setUserId(userId);
				info.setOperatorTime(operatorTime);
				int row2 = infoMapper.insertBicycleInfo(info);//新增一条车辆状态信息
				if(row2>0) {
					Integer bicycleId=info.getBicycleId();//获取新增车辆状态信息的id
					detail.setBicycleId(bicycleId);
					//2.新增车辆购入明细：
					detailMapper.insertDetail(detail);
					//3.新增业务流水信息：
						//createTime、dealName：新车购入登记、dealType:1、recordeId:车辆购入主单的id、isFee:1
					  	//chgMoney:每辆车的价格、feeType：2表支出、bicycleId、userId	
					BicycleDeal deal = new BicycleDeal();
					deal.setCreateTime(operatorTime);
					deal.setDealName("新车购入登记");
					deal.setDealType(1);
					deal.setRecordId(orderId);
					deal.setIsFee(1);
					deal.setChgMoney(price);
					deal.setFeeType(2);
					deal.setBicycleId(bicycleId);
					deal.setUserId(userId);
					dealMapper.insertBicycleDeal(deal);
				}
			}
		}
	}

}
