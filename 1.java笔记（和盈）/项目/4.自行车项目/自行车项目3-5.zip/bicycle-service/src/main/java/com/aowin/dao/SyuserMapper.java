package com.aowin.dao;

import java.util.List;

import com.aowin.model.Syuser;

public interface SyuserMapper {
	/**
	 * 登录
	 * @param syuser
	 * @return
	 */
	 Syuser login(Syuser syuser);
	/**
	 * 根据syuser查询用户
	 * @param syuser
	 * @return
	 */
	List<Syuser> select(Syuser syuser);
	/**
	 * 新增用户
	 * @param syuser
	 */
	void insert(Syuser syuser);
	/**
	 * 根据用户登录名称查询用户
	 * @param loginName
	 * @return
	 */
	List<Syuser> selectByLoginName(String loginName);
	/**
	 * 修改用户
	 * @param syuser
	 */
	void update(Syuser syuser);
	/**
	 * 删除用户
	 * @param userId
	 */
	void deleteById(Integer userId);
	/**
	 * 根据用户id查询用户信息：
	 * @param userId
	 * @return
	 */
	Syuser selectByUserId(Integer userId);
	/**
	 * 根据角色id查找是否存在该用户：
	 * @param roleId
	 * @return
	 */
	List<Syuser> selectByroleId(Integer roleId);
	/**
	 * 更新注销状态：
	 * @param userId
	 */
	void updateZxbj(Syuser syuser);
}
