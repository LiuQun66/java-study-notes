package com.aowin.dao;

import java.util.List;
import java.util.Map;

import com.aowin.model.SyPermission;

public interface SyPermissionMapper {
	/**
	 * 新增角色的权限
	 * @param map
	 */
	void insertSyPermission(Map<String,Integer> map);
	/**
	 * 根据角色id删除角色对应的权限
	 * @param roleId
	 */
	void deleteByRoleId(Integer roleId);
	/**
	 * 根据权限的id查询是否有对应的角色拥有该权限：
	 * @param phaseId
	 * @return
	 */
	List<SyPermission> selectByPhaseId(Integer phaseId);
	
}
