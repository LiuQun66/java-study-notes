package com.aowin.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BicycleDeal implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer dealId;
	private String createTime;
	private String dealName;
	private Integer dealType;
	private Integer recordId;
	private Integer cardId;
	private Integer isFee;
	private Double chgMoney;
	private Integer feeType;
	private Integer bicycleId;
	private Integer pileId;
	private Integer userId;
}
