package com.aowin.dao;

import java.util.List;

import com.aowin.model.Vender;

public interface VenderMapper {
	/**
	 * 查询供应商的信息：
	 * @return
	 */
	List<Vender> selectVenders();
}
