package com.aowin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aowin.constants.PageConfig;
import com.aowin.dao.BicycleDealMapper;
import com.aowin.dao.BicycleDeployMapper;
import com.aowin.dao.BicycleInfoMapper;
import com.aowin.dao.BicyclePileMapper;
import com.aowin.model.BicycleDeal;
import com.aowin.model.BicycleDeploy;
import com.aowin.model.BicycleInfo;
import com.aowin.service.BicycleInfoService;
import com.aowin.util.DateUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
@Service
public class BicycleInfoServiceImpl implements BicycleInfoService{
	@Autowired
	private BicycleInfoMapper infoMapper;
	@Autowired
	private BicyclePileMapper pileMapper;
	@Autowired
	private BicycleDeployMapper deployMapper;
	@Autowired
	private BicycleDealMapper dealMapper;
	/**
	 * 分页：
	 */
	@Override
	public PageInfo<BicycleInfo> select(int pageNum) {
		PageHelper.startPage(pageNum, PageConfig.PAGE_SIZE);
		List<BicycleInfo> infos=infoMapper.selectBicycleInfos();
		return new PageInfo<BicycleInfo>(infos);
	}
	/**
	 * 车辆入桩：修改车辆状态和车辆入桩信息
	 */
	@Transactional(propagation = Propagation.REQUIRED,readOnly = false, rollbackFor = Exception.class)
	@Override
	public void updateBicycleInfoAndPile(List<Integer> bicycleIdList, List<Integer> pileIdList,Integer userId) {
		for(int i=0;i<bicycleIdList.size();i++) {
			Integer bicycleId=bicycleIdList.get(i);
			Integer pileId=pileIdList.get(i);
			Map<String,Object> map=new HashMap<String,Object>();
			map.put("bicycleId", bicycleId);
			map.put("pileId", pileId);
			map.put("operatorTime", DateUtil.getDate());
			//修改车辆状态信息：
			infoMapper.updateBicycleInfoById(map);
			//修改车桩信息：
			pileMapper.updateBicyclePileById(map);
			//记录车辆调配明细：
			BicycleDeploy deploy=new BicycleDeploy();
			deploy.setBicycleId(bicycleId);
			deploy.setToPileId(pileId);
			deploy.setToTime(DateUtil.getDate());
			deploy.setToReason("1");
			deployMapper.insertBicycleDeploy(deploy);
			//记录车辆业务流水：
			BicycleDeal deal = new BicycleDeal();
			deal.setCreateTime(DateUtil.getDate());
			deal.setDealName("普通调入");
			deal.setDealType(5);
			deal.setRecordId(deploy.getDeployId());
			deal.setIsFee(0);
			deal.setChgMoney(0.0);
			deal.setBicycleId(bicycleId);
			deal.setPileId(pileId);
			deal.setUserId(userId);
			dealMapper.insertBicycleDeal(deal);
		}
		
	}
	

}
