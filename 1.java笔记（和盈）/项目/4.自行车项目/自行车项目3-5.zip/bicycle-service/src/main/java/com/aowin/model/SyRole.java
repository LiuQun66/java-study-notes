package com.aowin.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class SyRole implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer roleId;
	@NotEmpty
	private String roleName;
	private String roleDescribe;
	
	private List<String> authList;
}
