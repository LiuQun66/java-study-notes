package com.aowin.service;


import com.aowin.model.BicycleStation;
import com.github.pagehelper.PageInfo;

public interface BicycleStationService {
	/**
	 * 分页查询车点信息
	 * @param pageNum
	 * @return
	 */
	PageInfo<BicycleStation> select(int pageNum);
}
