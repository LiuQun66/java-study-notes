package com.aowin.dao;

import java.util.List;

import com.aowin.model.BicycleOrder;

public interface BicycleOrderMapper {
	/**
	 * 查询车辆购入主信息：
	 * @param bicycleOrder
	 * @return
	 */
	List<BicycleOrder> selectBicycleOrder(BicycleOrder bicycleOrder);
	/**
	 * 新增车辆购入主信息：
	 * @param bicycleOrder
	 */
	int insertBicycleOrder(BicycleOrder bicycleOrder);
}
