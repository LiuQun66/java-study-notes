package com.aowin.service;

import java.util.List;

import com.aowin.model.MsPhase;
import com.aowin.model.Syuser;
import com.github.pagehelper.PageInfo;

public interface SyuserService {
	/**
	 * 分页查询
	 * @param pageNum
	 * @param syuser
	 * @return
	 */
	PageInfo<Syuser> select(int pageNum,Syuser syuser);
	/**
	 * 登录
	 * @param syuser
	 * @return
	 */
	 Syuser login(Syuser syuser);
	 /**
	  * 新增用户
	  * @param syuser
	  */
	void insert(Syuser syuser);
	/**
	 * 根据用户登录名称查询用户
	 * @param loginName
	 * @return
	 */
	List<Syuser> selectByLoginName(String loginName);
	/**
	 * 修改用户
	 * @param syuser
	 */
	void update(Syuser syuser);
	/**
	 * 删除用户
	 * @param userId
	 */
	boolean deleteById(Integer userId);
	/**
	 * 更新注销状态：
	 * @param userId
	 */
	void updateZxbj(Syuser syuser);

}
