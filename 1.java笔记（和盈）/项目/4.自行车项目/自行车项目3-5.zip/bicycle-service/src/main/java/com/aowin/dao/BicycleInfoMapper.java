package com.aowin.dao;

import java.util.List;
import java.util.Map;

import com.aowin.model.BicycleInfo;

public interface BicycleInfoMapper {
	/**
	 * 新增车俩状态信息
	 * @param info
	 * @return
	 */
	int insertBicycleInfo(BicycleInfo info);
	/**
	 * 查询车辆状态信息中车辆编号的最大值
	 * @return
	 */
	Integer selectMaxCode();
	/**
	 * 查询车辆状态信息：
	 * @return
	 */
	List<BicycleInfo> selectBicycleInfos();
	/**
	 * 根据车辆id查询对应的车辆编号：
	 * @param bicycleId
	 * @return
	 */
	Integer selectById(Integer bicycleId);
	/**
	 * 根据车辆id更改车辆状态信息
	 * @param bicycleId
	 * @return
	 */
	int updateBicycleInfoById(Map<String,Object> map);
}
