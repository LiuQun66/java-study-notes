package com.aowin.service;

import java.util.List;

import com.aowin.model.SyRole;
import com.github.pagehelper.PageInfo;

public interface SyRoleService {
	PageInfo<SyRole> select(int pageNum,SyRole syRole);
	/**
	 * 查询角色信息
	 * @param syRole
	 * @return
	 */
	List<SyRole> selectSyRoles(SyRole syRole);
	
	/**
	 * 新增角色
	 * @param syRole
	 * @return
	 */
	 void insertSyRole(SyRole syRole);
	
	/**
	 * 修改角色
	 * @param syRole
	 * @return
	 */
	 void updateSyRole(SyRole syRole);
	
	
	/**
	 * 根据id查询角色
	 * @param syRoleId
	 * @return
	 */
	// SyRole selectById(int syRoleId);
	/**
	 * 根据id删除角色
	 * @param syRoleId
	 * @return
	 */
	 boolean deleteById(int syRoleId);
//	 /**
//	  * 根据id查询出角色对应的权限信息
//	  * @param syRoleId
//	  * @return
//	  */
//	 SyRole selectPhaseDescribeById(int syRoleId);
	 /**
	  * 根据角色名称查询角色id
	  * @param roleName
	  * @return
	  */
	 List<Integer> selectByRoleName(String roleName);
}
