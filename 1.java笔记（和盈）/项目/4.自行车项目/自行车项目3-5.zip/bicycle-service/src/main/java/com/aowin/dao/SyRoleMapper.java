package com.aowin.dao;

import java.util.List;

import com.aowin.model.SyRole;

public interface SyRoleMapper {
	/**
	 * 查询角色信息
	 * @param syRole
	 * @return
	 */
	List<SyRole> selectSyRoles(SyRole syRole);
	
	/**
	 * 新增角色
	 * @param syRole
	 * @return
	 */
	 int insertSyRole(SyRole syRole);
	
	/**
	 * 修改角色
	 * @param syRole
	 * @return
	 */
	 int updateSyRole(SyRole syRole);
	
	
	/**
	 * 根据id查询角色
	 * @param syRoleId
	 * @return
	 */
	 SyRole selectById(int syRoleId);
	/**
	 * 根据id删除角色
	 * @param syRoleId
	 * @return
	 */
	 int deleteById(int syRoleId);
	 /**
	  * 根据角色名称查询角色id
	  * @param roleName
	  * @return
	  */
	 List<Integer> selectByRoleName(String roleName);
}
