package com.aowin.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Vender {
	private Integer venderId;
	private String venderCode;
	private String venderType;
	private String venderName;
}
