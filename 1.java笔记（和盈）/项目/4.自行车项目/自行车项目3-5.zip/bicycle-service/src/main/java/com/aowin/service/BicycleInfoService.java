package com.aowin.service;


import java.util.List;

import com.aowin.model.BicycleInfo;
import com.github.pagehelper.PageInfo;

public interface BicycleInfoService {
	/**
	 * 分页：
	 * @param pageNum
	 * @return
	 */
	PageInfo<BicycleInfo> select(int pageNum);
	/**
	 * 车辆入桩：修改车辆状态和车辆入桩信息
	 * @param bicycleIdList
	 * @param pileIdList
	 */
	void updateBicycleInfoAndPile(List<Integer> bicycleIdList,List<Integer> pileIdList,Integer userId);
}
