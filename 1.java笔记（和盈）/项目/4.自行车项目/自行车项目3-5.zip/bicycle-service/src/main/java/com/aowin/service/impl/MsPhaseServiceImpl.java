package com.aowin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aowin.constants.PageConfig;
import com.aowin.dao.MsPhaseMapper;
import com.aowin.dao.SyPermissionMapper;
import com.aowin.model.MsPhase;
import com.aowin.model.SyPermission;
import com.aowin.service.MsPhaseService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Service
public class MsPhaseServiceImpl implements MsPhaseService {

	@Autowired
	private MsPhaseMapper msPhaseMapper;
	@Autowired
	private SyPermissionMapper permissionMapper;

	/**
	 * 分页查询
	 * 
	 * @param pageNum
	 * @param msPhase
	 * @return
	 */
	public PageInfo<MsPhase> select(int pageNum, MsPhase msPhase) {
		PageHelper.startPage(pageNum, PageConfig.PAGE_SIZE);
		List<MsPhase> phases = msPhaseMapper.select(msPhase);

		return new PageInfo<MsPhase>(phases);
	}

	/**
	 * 新增权限
	 * 
	 * @param msPhone
	 * @return
	 */
	public int insert(MsPhase msPhase) {
		return msPhaseMapper.insert(msPhase);
	}

	/**
	 * 修改权限
	 * 
	 * @param msPhase
	 * @return
	 */
	public boolean update(MsPhase msPhase) {
		// 前端传来的phaseId、url
		// 根据url从数据库中查询出的phaseId:
		// 若phaseId相同，说明前端没修改url；或者查询的MsPhase是空的，说明url不重复。可直接更新
		// 若phaseId不同，则表示重复的url，不能执行更新操作：
		String newUrl = msPhase.getUrl();
		Integer newPhaseId = msPhase.getPhaseId();
		MsPhase phase = msPhaseMapper.selectMsPhaseByUrl(newUrl);
		if (phase != null && phase.getPhaseId() != newPhaseId) {
			return false;
		} else {
			msPhaseMapper.update(msPhase);
			return true;
		}

	}

	/**
	 * 删除权限
	 * 
	 * @param phaseId
	 * @return
	 */
	public boolean delete(int phaseId) {
		// 删除权限之前查询角色是否有对应的权限，若没有则可以删除，若有则不能删除：
		List<SyPermission> roleList = permissionMapper.selectByPhaseId(phaseId);
		if (roleList != null&&roleList.size()>0) {
			return false;
		} else {
			msPhaseMapper.delete(phaseId);
			return true;
		}
	}

	/**
	 * 根据id查询权限
	 * 
	 * @param phaseId
	 * @return
	 */
	public MsPhase selectById(int phaseId) {
		return msPhaseMapper.selectById(phaseId);
	}

	/**
	 * 根据url查询数据库中的权限是否有对应的url
	 */
	@Override
	public MsPhase selectMsPhaseByUrl(String url) {
		return msPhaseMapper.selectMsPhaseByUrl(url);
	}

	/**
	 * 查询所有的权限信息
	 */
	@Override
	public List<MsPhase> selectMsPhases(MsPhase msPhase) {
		return msPhaseMapper.select(msPhase);
	}
}
