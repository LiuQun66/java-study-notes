package com.aowin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aowin.dao.BicycleCatagoryMapper;
import com.aowin.model.BicycleCatagory;
import com.aowin.service.BicycleCatagoryService;
@Service
public class BicycleCatagoryServiceImpl implements BicycleCatagoryService{
	@Autowired
	private BicycleCatagoryMapper catagoryMapper;
	/**
	 * 查询自行车的种类：
	 */
	@Override
	public List<BicycleCatagory> selectCatagorys() {
		return catagoryMapper.selectCatagorys();
	}

}
