package com.aowin.model;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class BicyclePile implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer pileId;
	private Integer stationId;
	private Integer venderId;
	private String pileCode;
	private Integer status;
	private String installTime;
	private String disasemblyTime;
	private Integer userId;
	private String operatorTime;
	private Integer bicycleId;
	private Integer bicycleCode;
	private String remark;
}
