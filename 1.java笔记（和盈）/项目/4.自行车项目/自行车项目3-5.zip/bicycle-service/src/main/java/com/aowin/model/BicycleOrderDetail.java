package com.aowin.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BicycleOrderDetail implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer detailId;
	private Integer catagoryId;
	private String catagoryName;
	private Integer orderId;
	private Integer bicycleId;
	private String bicycleCode;
	private String createDate;
	private String batchNo;
	private Double price;
	private String remark;
}
