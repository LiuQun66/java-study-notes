package com.aowin.util;

import java.util.ArrayList;
import java.util.List;

//字符串解析工具类
public class StringParseUtil {
	/**
	 * 去除多余的引号和括号，比如前端发送的数据是：[["/syuser","/card","/station","/repaire","/ttt"]]
	 * @param oldAuthList
	 * @return
	 */
	public static List<String> parseStringList(List<String> oldAuthList) {
		List<String> newAuthList = new ArrayList<String>();
//		if(oldAuthList.size()==1) {
//			String str=oldAuthList.get(0).replace("\"", "");
//			String st=str.replace("[", "");
//			newAuthList.add(st.replace("]", ""));
//		}else {
			for(int i=0;i<oldAuthList.size();i++) {
				String str = oldAuthList.get(i).replace("\"", "");
				if(oldAuthList.size()==1) {
					String st=str.replace("[", "");
					newAuthList.add(st.replace("]", ""));
				}else {
					if (i == 0) {
						newAuthList.add(str.replace("[", ""));
					} else if (i == oldAuthList.size() - 1) {
						newAuthList.add(str.replace("]", ""));
					} else {
						newAuthList.add(str);
					}
				}
			}
//		}
		return newAuthList;
	}
}
