package com.aowin.service;

import java.util.List;

import com.aowin.model.BicyclePile;

public interface BicyclePileService {
	/**
	 * 根据车点id查询对应的车桩信息：
	 * @param stationId
	 * @return
	 */
	List<BicyclePile> selectPilesById(Integer stationId);
}
