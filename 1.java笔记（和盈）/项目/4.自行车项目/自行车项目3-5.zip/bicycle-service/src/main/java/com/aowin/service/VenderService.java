package com.aowin.service;

import java.util.List;

import com.aowin.model.Vender;

public interface VenderService {
	/**
	 * 查询供应商的信息：
	 * @return
	 */
	List<Vender> selectVenders();
}
