package com.aowin.model;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class BicycleDeploy implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer deployId;
	private Integer bicycleId;
	private Integer fromPileId;
	private Integer toPileId;
	private Integer fromCardId;
	private String  fromTime;
	private Integer toCardId;
	private String toTime;
	private String toReason;
	private String fromReason;
	private String remark;
	private String status;
	

}
