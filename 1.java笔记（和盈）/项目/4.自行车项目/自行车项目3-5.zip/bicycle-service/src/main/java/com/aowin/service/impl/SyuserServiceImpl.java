package com.aowin.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aowin.constants.PageConfig;
import com.aowin.dao.SyRoleMapper;
import com.aowin.dao.SyuserMapper;
import com.aowin.model.SyRole;
import com.aowin.model.Syuser;
import com.aowin.service.SyuserService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Service
public class SyuserServiceImpl implements SyuserService{
	
	@Autowired
	private SyuserMapper syuserMapper;
	@Autowired
	private SyRoleMapper syRoleMapper;

	public Syuser login(Syuser syuser) {
		return syuserMapper.login(syuser);
	}
	/**
	 * 分页查询
	 */
	@Override
	public PageInfo<Syuser> select(int pageNum, Syuser syuser) {
		PageHelper.startPage(pageNum, PageConfig.PAGE_SIZE);
		List<Syuser> syusers = syuserMapper.select(syuser);
		return new PageInfo<Syuser>(syusers);
	}
	/**
	 * 新增用户：
	 */
	@Override
	public void insert(Syuser syuser) {
		//根据角色名称查找角色表对应的角色id:
		List<Integer> idList = syRoleMapper.selectByRoleName(syuser.getRoleName());
		if(idList==null||idList.size()>1) {
			throw new RuntimeException("无法根据角色信息查询到唯一的角色id");
		}else {
			syuser.setRoleId(idList.get(0));
			//新增用户：
			 syuserMapper.insert(syuser);
		}
	}
	/**
	 * 根据用户登录名称查询用户
	 */
	@Override
	public List<Syuser> selectByLoginName(String loginName) {
		return syuserMapper.selectByLoginName(loginName);
	}
	/**
	 * 修改用户
	 * @param syuser
	 */
	@Override
	public void update(Syuser syuser) {
		syuserMapper.update(syuser);
	}
	/**
	 * 删除用户
	 * @param userId
	 */
	@Override
	public boolean deleteById(Integer userId) {
		//如果用户已注销才能够删除，否则不能删除用户：
		Syuser syuser = syuserMapper.selectByUserId(userId);
		if("2".equals(syuser.getZxbj())) {
			syuserMapper.deleteById(userId);
			return true;
		}else {
			return false;
		}
		
	}
	/**
	 * 更改注销状态
	 */
	@Override
	public void updateZxbj(Syuser syuser) {
		syuserMapper.updateZxbj(syuser);
	}

}
