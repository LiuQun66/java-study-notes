package com.aowin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aowin.dao.BicycleOrderDetailMapper;
import com.aowin.model.BicycleOrderDetail;
import com.aowin.service.BicycleOrderDetailService;
@Service
public class BicycleOrderDetailServiceImpl  implements BicycleOrderDetailService{
	@Autowired
	private BicycleOrderDetailMapper detailMapper;
	
	/**
	 * 根据车辆购入主单的id查询对应的明细单信息
	 * @param orderId
	 * @return
	 */
	@Override
	public List<BicycleOrderDetail> selectByOrderId(Integer orderId) {
		return detailMapper.selectByOrderId(orderId);
	}

}
