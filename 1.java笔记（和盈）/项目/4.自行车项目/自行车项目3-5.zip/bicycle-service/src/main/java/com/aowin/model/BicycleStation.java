package com.aowin.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BicycleStation implements Serializable{
	private static final long serialVersionUID = 1L;
	private Integer stationId;
	private String stationCode;
	private String stationName;
	private Double longitude;
	private Double latitude;
	private Double bicyclePileNum;
	private String address;
	private String personInCharge;
	private String buildTime;
	private String runTime;
	private Integer userId;
	private String createTime;
	private String remark;
}
